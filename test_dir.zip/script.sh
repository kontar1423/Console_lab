#!/bin/bash
# Простой bash скрипт для демонстрации

echo "Hello from bash script!"
echo "Current date: $(date)"
echo "Python version: $(python3 --version)"

