# Руководство по тестированию консольного приложения

## 📁 Структура тестовой директории

```
test_dir/
├── README.md          - Информация о директории
├── hello.txt          - Простой русский текст
├── numbers.txt        - Список чисел
├── poem.txt           - Стихотворение
├── config.json        - JSON файл
├── script.sh          - Исполняемый bash скрипт
├── binary.dat         - Бинарные данные
├── subfolder/         - Вложенная папка
│   └── nested.txt     - Файл в подкаталоге
└── TESTING_GUIDE.md   - Это руководство
```

## 🧪 Команды для тренировки

### 1. Просмотр списка файлов

```bash
# Показать все файлы в test_dir
uv run python -m src.main ls test_dir

# Показать файлы во вложенной папке
uv run python -m src.main ls test_dir/subfolder

# Попробовать несуществующую директорию (проверка ошибок)
uv run python -m src.main ls nonexistent
```

### 2. Чтение текстовых файлов

```bash
# Прочитать простое приветствие
uv run python -m src.main cat test_dir/hello.txt

# Прочитать список чисел
uv run python -m src.main cat test_dir/numbers.txt

# Прочитать стихотворение
uv run python -m src.main cat test_dir/poem.txt

# Прочитать JSON
uv run python -m src.main cat test_dir/config.json

# Прочитать файл из подпапки
uv run python -m src.main cat test_dir/subfolder/nested.txt

# Прочитать README
uv run python -m src.main cat test_dir/README.md
```

### 3. Чтение бинарных файлов

```bash
# Читать бинарный файл как байты
uv run python -m src.main cat test_dir/binary.dat --bytes

# Также можно использовать короткую версию флага
uv run python -m src.main cat test_dir/binary.dat -b
```

### 4. Тестирование обработки ошибок

```bash
# Попытка прочитать несуществующий файл
uv run python -m src.main cat test_dir/missing.txt

# Попытка прочитать директорию как файл
uv run python -m src.main cat test_dir/subfolder

# Попытка показать директорию, которой нет
uv run python -m src.main ls /nonexistent/path
```

## 📝 Логирование

Все команды записывают логи в файл `app.log` в корне проекта.
Включено логирование в:
- INFO - успешные операции
- ERROR - ошибки

Проверьте логи командой:
```bash
cat app.log
```

## 🎯 Интересные кейсы для проверки

1. **Вложенные папки** - работает ли рекурсивный обход
2. **Кириллица** - корректно ли отображаются русские символы
3. **Бинарные данные** - правильная ли работа с байтами
4. **JSON** - читается ли структурированный файл
5. **Ошибки** - информативные ли сообщения об ошибках
6. **Логирование** - записываются ли все операции

## 🚀 Расширенное использование

Сочетайте команды с Unix-пайпами:

```bash
# Подсчитать количество файлов
uv run python -m src.main ls test_dir | wc -l

# Поиск по содержимому
uv run python -m src.main cat test_dir/hello.txt | grep "консольной"

# Сохранить вывод в файл
uv run python -m src.main ls test_dir > output.txt
```

